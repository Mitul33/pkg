def summ(n1,n2):
    c=n1+n2
    print('result is : ',c)

def subb(n1,n2):
    c=n1-n2
    print('result is : ',c)
   
