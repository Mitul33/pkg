def mul(n1,n2):
    c=n1*n2
    print('result is : ',c)

def divv(n1,n2):
    c=n1/n2
    print('result is : ',c)
